fh = File.readlines('fradulent_emails.txt') # fradulent_emails test_emails
countries = File.readlines('countries-list.txt')
s1 = fh.join("")
s2 = countries.join("")
contents = s1.split("From r")
countriesList = s2.split("\n")

contents.shift
emails = []

for item in contents
  emails_dict = {}
  countries_list_name = []
  s_email = s_name = r_email = r_name = date = subject_field = full_email = dollar = percent = nil

  sender = (item.match /From:.*/).to_s
  if (sender)
    s_email = (sender.match /\w\S*@.*\w/).to_s
    s_name  = (sender.match /:.*</).to_s
    emails_dict["sender_email"] = s_email if !s_email.empty?
    emails_dict["sender_name"] = s_name.gsub(/\s*<|:\s*|\"/,"") if !s_name.empty?
  end
  # recipient = (item.scan /To:.*/).to_s
  recipient = (item.match /(?<!Reply-)To:.*/).to_s
  if recipient
    r_email = (recipient.match /\w\S*@.*\w/).to_s
    r_name = (recipient.match /:.*</).to_s
    emails_dict["recipient_email"] = r_email if !r_email.empty?
    emails_dict["recipient_name"] = r_name.gsub(/\s*<|:\s*|\"/,"").to_s if !r_name.empty?
  end

  date_field = (item.match /Date:.*/).to_s
  date = (date_field.match /\d+\s\w+\s\d+/).to_s if date_field
  emails_dict["date_sent"] = date if !date.empty?

  subject_field = (item.match /Subject: .*/).to_s
  emails_dict["subject"] = subject_field.gsub(/Subject: /, "") if !subject_field.empty?

  full_email = item.match /Status:.*/m

  if (full_email)
    dollar = (full_email.to_s.scan /\w+\$\w+/m)
    percent = (full_email.to_s.scan /\d+%/m)
    emails_dict["dollar"] = dollar.to_s if !dollar.empty?
    emails_dict["percent"] = percent.to_s if !percent.empty?

    for cl in countriesList
      countries = (full_email.to_s.scan /#{cl}/im)
      countries_list_name += countries if countries
    end
    emails_dict["countries"] = countries_list_name.uniq if !countries_list_name.empty?
  end

  emails.push(emails_dict)
end

puts("Number of emails: " + (emails.length).to_s)

for index in (0..emails.length-1)
  puts "Email No : " + (index+1).to_s
  for key, value in emails[index]
    puts(key.to_s + ": " + value.to_s)
  end
  puts "\n"
end
